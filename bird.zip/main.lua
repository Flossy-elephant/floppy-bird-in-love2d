require("bird")
require("pipe")
function love.load()
bird:load()
pipe:load()
score=0
end

function love.update(dt)
bird:update(dt)
pipe:update(dt)
love:score()
end

function love.draw()
   love.graphics.setColor(.14, .36, .46)
   love.graphics.rectangle('fill', 0, 0, love.graphics.getWidth(), love.graphics.getHeight())
   bird:draw()
   pipe:draw()
   love.graphics.setColor(1, 1, 1)
   love.graphics.print("Score: "..score, 15,15)
end

function love:score()
   if not pipe.passed1 and bird.x > pipe.x1 + pipe.width then
      score = score + 1
      pipe.passed1 = true
   end
   if not pipe.passed2 and bird.x > pipe.x2 + pipe.width then
      score = score + 1
      pipe.passed2 = true
   end
end


