function love.conf(t)
    t.title="birdy"
    t.version="11.5"
    t.console=true
    t.window.width=512
    t.window.height=768
    
end